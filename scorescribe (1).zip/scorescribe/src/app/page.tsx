import Link from "next/link";
import { LEAGUES } from "@/lib/leagues";
import PayPanel from "@/components/PayPanel";

export default function Home() {
  const group = (s: "Football" | "Basketball") => LEAGUES.filter((l) => l.sport === s);
  return (
    <div>
      <h1 className="font-display text-5xl font-bold leading-tight">Tips built from head-to-head data.</h1>
      <p className="mt-4 max-w-xl text-lg text-mute">Goals, BTTS, corners, cards and totals. We never tip a straight win.</p>

      {(["Football", "Basketball"] as const).map((s) => (
        <section key={s} className="mt-10">
          <h2 className="font-display text-2xl font-semibold">{s}</h2>
          <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-3">
            {group(s).map((l) => (
              <Link key={l.slug} href={`/${l.slug}`} className="rounded-xl border border-edge bg-panel px-4 py-4 font-medium hover:border-neon">
                {l.name}
              </Link>
            ))}
          </div>
        </section>
      ))}

      <section id="vip" className="mt-14 rounded-2xl border border-neon/40 p-6">
        <h2 className="font-display text-2xl font-semibold">Unlock every tip</h2>
        <p className="mt-1 text-mute">Each league shows 3 free tips per Gameweek. VIP opens the other 7 in all 12 leagues.</p>
        <PayPanel next="/" />
      </section>
    </div>
  );
}
