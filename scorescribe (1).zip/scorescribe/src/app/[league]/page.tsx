import { notFound } from "next/navigation";
import Link from "next/link";
import { findLeague } from "@/lib/leagues";
import { db } from "@/lib/supabase";
import { isPremium } from "@/lib/session";
import { isAllowedTip } from "@/lib/rules";
import type { Tip } from "@/lib/types";
import TipCard from "@/components/TipCard";
import LockedBlock from "@/components/LockedBlock";
import AdSlot from "@/components/AdSlot";

export const dynamic = "force-dynamic";

export default async function LeaguePage({ params, searchParams }: { params: { league: string }; searchParams: { pay?: string } }) {
  const league = findLeague(params.league);
  if (!league) notFound();

  const premium = await isPremium();
  const { data } = await db().from("scorescribe_tips").select("*")
    .eq("league", league.name).eq("sport", league.sport)
    .order("created_at", { ascending: false }).limit(10);

  // Newest batch, oldest-first; anything that is not an allowed (non straight-win) market never renders.
  const rows = ((data ?? []) as Tip[]).reverse().filter((r) => isAllowedTip(r.sport, r.tip));
  const free = rows.filter((r) => r.is_free);
  const locked = rows.filter((r) => !r.is_free);
  const gw = rows[0]?.gameweek;

  return (
    <div>
      <Link href="/" className="text-sm text-mute hover:text-neon">All leagues</Link>
      <h1 className="mt-2 font-display text-4xl font-bold">{league.name}</h1>
      <p className="mt-1 text-mute">{league.sport}{gw ? ` · Gameweek ${gw}` : ""}</p>

      {searchParams.pay === "success" && <p className="mt-4 rounded-lg border border-neon/50 p-3 text-neon">Payment confirmed. All tips are unlocked.</p>}
      {searchParams.pay === "failed" && <p role="alert" className="mt-4 rounded-lg border border-red-500/50 p-3 text-red-400">We could not confirm that payment. If you were charged, contact support with your Paystack reference.</p>}

      {rows.length === 0 ? (
        <p className="mt-8 rounded-xl border border-edge p-6 text-mute">No tips yet for this league. New tips are published every Friday at 6am WAT.</p>
      ) : premium ? (
        <div className="mt-6 space-y-4">{rows.map((t) => <TipCard key={t.id} t={t} />)}</div>
      ) : (
        <>
          <div className="mt-6 space-y-4">
            {free.map((t, i) => (
              <div key={t.id} className="space-y-4">
                <TipCard t={t} />
                {(i === 0 || i === 2) && <AdSlot />}
              </div>
            ))}
          </div>
          {locked.length > 0 && <LockedBlock items={locked.map((t) => ({ id: t.id, match: t.match }))} next={`/${league.slug}`} />}
        </>
      )}
    </div>
  );
}
