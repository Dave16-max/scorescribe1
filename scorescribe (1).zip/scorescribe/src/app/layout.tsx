import type { Metadata } from "next";
import Script from "next/script";
import { Bricolage_Grotesque, Instrument_Sans } from "next/font/google";
import Header from "@/components/Header";
import "./globals.css";

const display = Bricolage_Grotesque({ subsets: ["latin"], variable: "--font-display" });
const body = Instrument_Sans({ subsets: ["latin"], variable: "--font-body" });

export const metadata: Metadata = {
  title: "ScoreScribe - Data-driven football and basketball tips",
  description: "Goals, BTTS, corners, cards and totals tips built from head-to-head data. No straight-win picks.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const ads = process.env.NEXT_PUBLIC_ADSENSE_CLIENT;
  return (
    <html lang="en" className={`${display.variable} ${body.variable}`}>
      <body className="min-h-screen font-body antialiased">
        {ads && <Script async src={`https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${ads}`} crossOrigin="anonymous" strategy="afterInteractive" />}
        <Header />
        <main className="mx-auto max-w-3xl px-4 pb-24 pt-8">{children}</main>
        <footer className="mx-auto max-w-3xl border-t border-edge px-4 py-8 text-sm text-mute">
          Tips are analysis, not guarantees. Odds shown are estimates. 18+ only. Bet responsibly.
        </footer>
      </body>
    </html>
  );
}
