import { NextRequest, NextResponse } from "next/server";
import { LEAGUES, findLeague } from "@/lib/leagues";
import { generateForLeague } from "@/lib/generate";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

// Vercel Cron calls GET with "Authorization: Bearer <CRON_SECRET>".
async function handler(req: NextRequest) {
  const secret = process.env.CRON_SECRET;
  const auth = req.headers.get("authorization");
  if (!secret || auth !== `Bearer ${secret}`) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const slug = req.nextUrl.searchParams.get("league");
  if (slug) {
    const league = findLeague(slug);
    if (!league) return NextResponse.json({ error: "Unknown league" }, { status: 404 });
    try { return NextResponse.json(await generateForLeague(league)); }
    catch (e) { return NextResponse.json({ error: (e as Error).message }, { status: 500 }); }
  }

  // No league given: fan out one request per league so each gets its own time budget.
  const origin = process.env.SITE_URL || req.nextUrl.origin;
  const results = await Promise.allSettled(
    LEAGUES.map(async (l) => {
      const r = await fetch(`${origin}/api/generate?league=${l.slug}`, { headers: { authorization: auth! }, cache: "no-store" });
      return { league: l.name, status: r.status, ...(await r.json().catch(() => ({}))) };
    })
  );
  return NextResponse.json(results.map((r) => (r.status === "fulfilled" ? r.value : { error: String(r.reason) })));
}
export const GET = handler;
export const POST = handler;
