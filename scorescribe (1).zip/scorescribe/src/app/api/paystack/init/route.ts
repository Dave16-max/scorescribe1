import { NextRequest, NextResponse } from "next/server";
import { PLANS, type PlanKey } from "@/lib/plans";

export async function POST(req: NextRequest) {
  const { email, plan, next } = await req.json().catch(() => ({}));
  if (typeof email !== "string" || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
    return NextResponse.json({ error: "Enter a valid email address." }, { status: 400 });
  }
  if (!(plan in PLANS)) return NextResponse.json({ error: "Choose a plan." }, { status: 400 });
  const p = PLANS[plan as PlanKey];
  const safeNext = typeof next === "string" && next.startsWith("/") && !next.startsWith("//") ? next : "/";
  const origin = process.env.SITE_URL || req.nextUrl.origin;

  const r = await fetch("https://api.paystack.co/transaction/initialize", {
    method: "POST",
    headers: { Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      email: email.toLowerCase(), amount: p.amount, currency: "NGN",
      callback_url: `${origin}/api/paystack/verify`,
      metadata: { plan, next: safeNext },
    }),
  });
  const j = await r.json();
  if (!r.ok || !j.status) return NextResponse.json({ error: "Could not start payment. Try again." }, { status: 502 });
  return NextResponse.json({ url: j.data.authorization_url });
}
