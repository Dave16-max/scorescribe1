import { NextRequest, NextResponse } from "next/server";
import { PLANS, type PlanKey } from "@/lib/plans";
import { db } from "@/lib/supabase";
import { COOKIE, signEmail } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const ref = req.nextUrl.searchParams.get("reference") || req.nextUrl.searchParams.get("trxref");
  const back = (path: string, q: string) => NextResponse.redirect(new URL(`${path}${path.includes("?") ? "&" : "?"}${q}`, req.url));
  if (!ref) return back("/", "pay=failed");

  const r = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(ref)}`, {
    headers: { Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}` }, cache: "no-store",
  });
  const j = await r.json().catch(() => null);
  const d = j?.data;
  const next: string = typeof d?.metadata?.next === "string" && d.metadata.next.startsWith("/") && !d.metadata.next.startsWith("//") ? d.metadata.next : "/";

  const plan = PLANS[d?.metadata?.plan as PlanKey];
  if (!j?.status || d?.status !== "success" || !plan || d.amount !== plan.amount || d.currency !== "NGN") {
    return back(next, "pay=failed");
  }

  const email = String(d.customer.email).toLowerCase();
  const sb = db();
  const { data: existing } = await sb.from("scorescribe_subscribers").select("expires_at,last_reference").eq("email", email).maybeSingle();

  // Idempotent: the same reference never extends access twice.
  if (existing?.last_reference !== ref) {
    const startFrom = Math.max(Date.now(), existing?.expires_at ? new Date(existing.expires_at).getTime() : 0);
    const { error } = await sb.from("scorescribe_subscribers").upsert({
      email, is_premium: true, plan: d.metadata.plan,
      expires_at: new Date(startFrom + plan.days * 86400000).toISOString(),
      last_reference: ref, updated_at: new Date().toISOString(),
    });
    if (error) return back(next, "pay=failed");
  }

  const res = back(next, "pay=success");
  res.cookies.set(COOKIE, signEmail(email), {
    httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/", maxAge: 60 * 60 * 24 * 35,
  });
  return res;
}
