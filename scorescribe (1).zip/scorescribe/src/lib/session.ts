import "server-only";
import crypto from "crypto";
import { cookies } from "next/headers";
import { db } from "./supabase";

export const COOKIE = "ss_session";
const secret = () => {
  const s = process.env.SESSION_SECRET;
  if (!s) throw new Error("SESSION_SECRET missing");
  return s;
};
const sig = (v: string) => crypto.createHmac("sha256", secret()).update(v).digest("base64url");

export function signEmail(email: string) {
  const v = Buffer.from(email).toString("base64url");
  return `${v}.${sig(v)}`;
}

function readEmail(raw?: string): string | null {
  if (!raw) return null;
  const [v, s] = raw.split(".");
  if (!v || !s) return null;
  const expected = sig(v);
  if (s.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(s), Buffer.from(expected))) return null;
  return Buffer.from(v, "base64url").toString();
}

export async function isPremium(): Promise<boolean> {
  const email = readEmail(cookies().get(COOKIE)?.value);
  if (!email) return false;
  const { data } = await db()
    .from("scorescribe_subscribers")
    .select("is_premium, expires_at")
    .eq("email", email)
    .maybeSingle();
  return !!data?.is_premium && !!data.expires_at && new Date(data.expires_at).getTime() > Date.now();
}
