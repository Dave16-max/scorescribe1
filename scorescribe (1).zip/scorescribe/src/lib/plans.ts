export const PLANS = {
  week: { amount: 490000, days: 7, label: "7 days", price: "₦4,900" },
  month: { amount: 1790000, days: 30, label: "30 days", price: "₦17,900" },
} as const;
export type PlanKey = keyof typeof PLANS;
