import type { Sport } from "./leagues";

// Straight-win / result markets: always rejected.
const FORBIDDEN = /\b(home win|away win|win|draw|moneyline|winner|1x2)\b|^\s*[12x]\s*$/i;
const FORBIDDEN_IN_TEXT = /\b(home win|away win|straight win|moneyline|1x2)\b/i;

const FOOTBALL_OK = [
  /^btts\s*(yes|no)$/i,
  /^both teams to score\s*[-:]?\s*(yes|no)$/i,
  /^over 1\.5 goals$/i,
  /^over 2\.5 goals$/i,
  /^under 2\.5 goals$/i,
  /^double chance\s*[-:]?\s*\(?(1x|x2)\)?$/i,
  /^(1x|x2)$/i,
  /^over 8\.5 corners$/i,
  /^over 3\.5 cards$/i,
];

const BASKETBALL_OK = [
  /^(over|under)\s+\d{2,3}(\.5)?(\s+total points)?$/i,
  /^(home|away)\s+[+-]\d{1,2}(\.5)?$/i,
  /^(home|away) team (over|under) \d{2,3}(\.5)? points$/i,
];

export function isAllowedTip(sport: Sport, tip: string): boolean {
  const t = (tip || "").trim();
  if (!t || FORBIDDEN.test(t)) return false;
  return (sport === "Football" ? FOOTBALL_OK : BASKETBALL_OK).some((r) => r.test(t));
}

export const analysisIsClean = (a: string) => !FORBIDDEN_IN_TEXT.test(a || "");
