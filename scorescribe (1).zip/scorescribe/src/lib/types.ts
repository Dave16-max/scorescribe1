export interface Tip {
  id: string; sport: "Football" | "Basketball"; league: string; gameweek: number | null;
  match: string; home_team: string; away_team: string; tip: string; analysis: string;
  confidence: number | null; odd: string | null; is_free: boolean; fixture_id: number; created_at: string;
}
