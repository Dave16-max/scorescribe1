export type Sport = "Football" | "Basketball";
export interface League { slug: string; name: string; id: number; sport: Sport; season: string }

export const FOOTBALL_BASE = "https://v3.football.api-sports.io";
export const BASKETBALL_BASE = process.env.BASKETBALL_API_BASE || "https://v1.basketball.api-sports.io";

export const LEAGUES: League[] = [
  { slug: "premier-league", name: "Premier League", id: 39, sport: "Football", season: "2024" },
  { slug: "ligue-1", name: "Ligue 1", id: 61, sport: "Football", season: "2024" },
  { slug: "la-liga", name: "La Liga", id: 140, sport: "Football", season: "2024" },
  { slug: "bundesliga", name: "Bundesliga", id: 78, sport: "Football", season: "2024" },
  { slug: "serie-a", name: "Serie A", id: 135, sport: "Football", season: "2024" },
  { slug: "champions-league", name: "Champions League", id: 2, sport: "Football", season: "2024" },
  { slug: "europa-league", name: "Europa League", id: 3, sport: "Football", season: "2024" },
  { slug: "conference-league", name: "Conference League", id: 848, sport: "Football", season: "2024" },
  { slug: "nba", name: "NBA", id: 12, sport: "Basketball", season: "2024-2025" },
  { slug: "ncaa", name: "NCAA", id: 1, sport: "Basketball", season: "2024-2025" },
  { slug: "wnba", name: "WNBA", id: 13, sport: "Basketball", season: "2024-2025" },
  { slug: "euroleague", name: "Euroleague", id: 3, sport: "Basketball", season: "2024-2025" },
];

export const findLeague = (slug: string) => LEAGUES.find((l) => l.slug === slug);
