import "server-only";
import type { League } from "./leagues";
import { getFixtures, getForm, getH2H } from "./apisports";
import { askClaude } from "./claude";
import { db } from "./supabase";

export async function generateForLeague(l: League) {
  const fixtures = await getFixtures(l);
  const rows: Record<string, unknown>[] = [];
  const errors: string[] = [];
  const base = Date.now();

  for (const f of fixtures) {
    try {
      const [h2h, homeForm, awayForm] = await Promise.all([
        getH2H(l, f), getForm(l, f.homeId, f.homeName), getForm(l, f.awayId, f.awayName),
      ]);
      const t = await askClaude(l, f, h2h, { home: homeForm, away: awayForm });
      rows.push({
        sport: l.sport, league: l.name, gameweek: f.gameweek,
        match: `${f.homeName} vs ${f.awayName}`, home_team: f.homeName, away_team: f.awayName,
        tip: t.tip, analysis: t.analysis, confidence: t.confidence, odd: t.odd,
        is_free: rows.length < 3, // first 3 saved = free, remaining 7 = locked
        fixture_id: f.id,
        created_at: new Date(base + rows.length).toISOString(), // keeps batch order stable
      });
    } catch (e) {
      errors.push(`${f.homeName} vs ${f.awayName}: ${(e as Error).message}`);
    }
  }

  if (rows.length) {
    const { error } = await db().from("scorescribe_tips").upsert(rows, { onConflict: "fixture_id" });
    if (error) throw new Error(error.message);
  }
  return { league: l.name, saved: rows.length, errors };
}
