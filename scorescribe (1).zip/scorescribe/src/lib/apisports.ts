import "server-only";
import { BASKETBALL_BASE, FOOTBALL_BASE, type League } from "./leagues";

export interface Fixture {
  id: number; date: string; status: string; gameweek: number;
  homeId: number; homeName: string; awayId: number; awayName: string;
}

// The key lives only in process.env.API_FOOTBALL_KEY and is only sent as a header from the server.
async function api(base: string, path: string): Promise<any[]> {
  const key = process.env.API_FOOTBALL_KEY;
  if (!key) throw new Error("API_FOOTBALL_KEY is not set");
  const res = await fetch(base + path, { headers: { "x-apisports-key": key }, cache: "no-store" });
  if (!res.ok) throw new Error(`API-Sports HTTP ${res.status} for ${path.split("?")[0]}`);
  const j = await res.json();
  const errs = j.errors;
  if (errs && (Array.isArray(errs) ? errs.length : Object.keys(errs).length)) {
    throw new Error("API-Sports: " + JSON.stringify(errs));
  }
  return j.response ?? [];
}

const isoWeek = (d: Date) => {
  const t = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
  t.setUTCDate(t.getUTCDate() + 4 - (t.getUTCDay() || 7));
  const y0 = new Date(Date.UTC(t.getUTCFullYear(), 0, 1));
  return Math.ceil(((t.getTime() - y0.getTime()) / 86400000 + 1) / 7);
};

const FINISHED = new Set(["FT", "AET", "PEN", "AOT"]);

function pick10(all: Fixture[]): Fixture[] {
  const now = Date.now();
  const upcoming = all.filter((f) => !FINISHED.has(f.status) && new Date(f.date).getTime() >= now)
    .sort((a, b) => +new Date(a.date) - +new Date(b.date));
  const past = all.filter((f) => !upcoming.includes(f)).sort((a, b) => +new Date(b.date) - +new Date(a.date));
  return [...upcoming, ...past].slice(0, 10).sort((a, b) => +new Date(a.date) - +new Date(b.date));
}

export async function getFixtures(l: League): Promise<Fixture[]> {
  if (l.sport === "Football") {
    const r = await api(FOOTBALL_BASE, `/fixtures?league=${l.id}&season=${l.season}`);
    return pick10(r.map((x) => {
      const m = /(\d+)\s*$/.exec(x.league?.round ?? "");
      return {
        id: x.fixture.id, date: x.fixture.date, status: x.fixture.status.short,
        gameweek: m ? +m[1] : isoWeek(new Date(x.fixture.date)),
        homeId: x.teams.home.id, homeName: x.teams.home.name, awayId: x.teams.away.id, awayName: x.teams.away.name,
      };
    }));
  }
  const r = await api(BASKETBALL_BASE, `/games?league=${l.id}&season=${l.season}`);
  return pick10(r.map((x) => ({
    id: x.id, date: x.date, status: x.status.short, gameweek: isoWeek(new Date(x.date)),
    homeId: x.teams.home.id, homeName: x.teams.home.name, awayId: x.teams.away.id, awayName: x.teams.away.name,
  })));
}

const avg = (a: number[]) => (a.length ? +(a.reduce((s, n) => s + n, 0) / a.length).toFixed(2) : null);

export async function getH2H(l: League, f: Fixture) {
  if (l.sport === "Football") {
    const r = (await api(FOOTBALL_BASE, `/fixtures/headtohead?h2h=${f.homeId}-${f.awayId}&last=10`))
      .filter((x) => FINISHED.has(x.fixture.status.short) && x.goals.home != null);
    const totals = r.map((x) => x.goals.home + x.goals.away);
    return {
      meetings: r.length,
      avgGoals: avg(totals),
      bttsCount: r.filter((x) => x.goals.home > 0 && x.goals.away > 0).length,
      over15Count: totals.filter((t) => t > 1.5).length,
      over25Count: totals.filter((t) => t > 2.5).length,
      results: r.map((x) => `${x.fixture.date.slice(0, 10)} ${x.teams.home.name} ${x.goals.home}-${x.goals.away} ${x.teams.away.name}`),
    };
  }
  const r = (await api(BASKETBALL_BASE, `/games?h2h=${f.homeId}-${f.awayId}`))
    .filter((x) => FINISHED.has(x.status.short) && x.scores.home.total != null)
    .sort((a, b) => +new Date(b.date) - +new Date(a.date)).slice(0, 10);
  const totals = r.map((x) => x.scores.home.total + x.scores.away.total);
  return {
    meetings: r.length,
    avgTotalPoints: avg(totals),
    avgHomePoints: avg(r.map((x) => x.scores.home.total)),
    avgAwayPoints: avg(r.map((x) => x.scores.away.total)),
    results: r.map((x) => `${x.date.slice(0, 10)} ${x.teams.home.name} ${x.scores.home.total}-${x.scores.away.total} ${x.teams.away.name}`),
  };
}

export async function getForm(l: League, teamId: number, teamName: string) {
  if (l.sport === "Football") {
    const r = (await api(FOOTBALL_BASE, `/fixtures?team=${teamId}&last=5`))
      .filter((x) => x.goals.home != null);
    const rows = r.map((x) => {
      const home = x.teams.home.id === teamId;
      const gf = home ? x.goals.home : x.goals.away, ga = home ? x.goals.away : x.goals.home;
      return { res: gf > ga ? "W" : gf < ga ? "L" : "D", gf, ga };
    });
    return {
      team: teamName, last5: rows.map((x) => x.res).join(""),
      goalsFor: rows.reduce((s, x) => s + x.gf, 0), goalsAgainst: rows.reduce((s, x) => s + x.ga, 0),
    };
  }
  const r = (await api(BASKETBALL_BASE, `/games?team=${teamId}&league=${l.id}&season=${l.season}`))
    .filter((x) => FINISHED.has(x.status.short) && x.scores.home.total != null)
    .sort((a, b) => +new Date(b.date) - +new Date(a.date)).slice(0, 5);
  const rows = r.map((x) => {
    const home = x.teams.home.id === teamId;
    const pf = home ? x.scores.home.total : x.scores.away.total, pa = home ? x.scores.away.total : x.scores.home.total;
    return { res: pf > pa ? "W" : "L", pf, pa };
  });
  return {
    team: teamName, last5: rows.map((x) => x.res).join(""),
    avgPointsFor: avg(rows.map((x) => x.pf)), avgPointsAgainst: avg(rows.map((x) => x.pa)),
  };
}
