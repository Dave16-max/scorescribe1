import "server-only";
import Anthropic from "@anthropic-ai/sdk";
import type { League } from "./leagues";
import type { Fixture } from "./apisports";
import { analysisIsClean, isAllowedTip } from "./rules";

export interface GeneratedTip { tip: string; odd: string; confidence: number; analysis: string }

function buildPrompt(l: League, f: Fixture, h2h: unknown, form: unknown) {
  return `You are ScoreScribe analyst. REAL DATA: Sport: ${l.sport}, League: ${l.name}, Fixture: ${f.homeName} vs ${f.awayName}, H2H: ${JSON.stringify(h2h)}, Form: ${JSON.stringify(form)}. RULE: NEVER predict straight win. FORBIDDEN tips: Home Win, Away Win, Draw, 1, X, 2, 1X2, Moneyline, Winner. ONLY ALLOWED: For Football: BTTS Yes/No, Over 1.5 Goals, Over 2.5 Goals, Under 2.5 Goals, Double Chance (1X or X2), Over 8.5 Corners, Over 3.5 Cards. For Basketball: Over/Under Total Points e.g Over 215.5, Under 210.5, Handicap/Spread e.g Home -5.5, Away +6.5, Over/Under Team Points (write as "Home Team Over 105.5 Points" or "Away Team Under 98.5 Points"). TASK: Give tip from allowed list only, 2 sentence analysis using H2H stats, confidence %. JSON only: {"tip":"Over 2.5 Goals","odd":"1.85","confidence":81,"analysis":"sentence 1 with H2H stat. sentence 2."}`;
}

function parse(text: string): GeneratedTip | null {
  const m = text.match(/\{[\s\S]*\}/);
  if (!m) return null;
  try {
    const j = JSON.parse(m[0]);
    const conf = Math.round(Number(j.confidence));
    const odd = String(j.odd ?? "").trim();
    if (!j.tip || !j.analysis || !Number.isFinite(conf) || !/^\d+(\.\d+)?$/.test(odd)) return null;
    return { tip: String(j.tip).trim(), odd, confidence: Math.min(99, Math.max(1, conf)), analysis: String(j.analysis).trim() };
  } catch { return null; }
}

export async function askClaude(l: League, f: Fixture, h2h: unknown, form: unknown): Promise<GeneratedTip> {
  const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
  const model = process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5";
  let prompt = buildPrompt(l, f, h2h, form);
  for (let attempt = 0; attempt < 3; attempt++) {
    const msg = await client.messages.create({ model, max_tokens: 400, messages: [{ role: "user", content: prompt }] });
    const text = msg.content.map((b) => (b.type === "text" ? b.text : "")).join("");
    const out = parse(text);
    if (out && isAllowedTip(l.sport, out.tip) && analysisIsClean(out.analysis)) return out;
    prompt = buildPrompt(l, f, h2h, form) + `\nYour previous answer was rejected (invalid tip or straight-win wording). Reply again with an ALLOWED tip only, JSON only.`;
  }
  throw new Error("No valid non-straight-win tip after 3 attempts");
}
