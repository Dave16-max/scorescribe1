import type { Tip } from "@/lib/types";

export default function TipCard({ t }: { t: Tip }) {
  const c = t.confidence ?? 0;
  return (
    <article className="rounded-2xl border border-edge bg-panel p-5">
      <h3 className="font-display text-lg font-semibold">{t.match}</h3>
      <div className="mt-3 flex flex-wrap items-center gap-3">
        <span className="rounded-lg bg-neon px-3 py-1 font-display text-base font-bold text-ink">{t.tip}</span>
        {t.odd && <span className="text-sm text-mute">Est. odd <b className="text-white">{t.odd}</b></span>}
      </div>
      <div className="mt-4" aria-label={`Confidence ${c} percent`}>
        <div className="flex justify-between text-sm"><span className="text-mute">Confidence</span><b>{c}%</b></div>
        <div className="mt-1 h-2 overflow-hidden rounded-full bg-edge"><div className="h-full rounded-full bg-neon" style={{ width: `${c}%` }} /></div>
      </div>
      <p className="mt-4 text-[15px] leading-relaxed text-[#cdd6d0]">{t.analysis}</p>
    </article>
  );
}
