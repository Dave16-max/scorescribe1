"use client";
import { useState } from "react";
import { PLANS, type PlanKey } from "@/lib/plans";

export default function PayPanel({ next }: { next: string }) {
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState<PlanKey | null>(null);
  const [err, setErr] = useState("");

  async function pay(plan: PlanKey) {
    setErr(""); setBusy(plan);
    try {
      const res = await fetch("/api/paystack/init", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ email, plan, next }) });
      const j = await res.json();
      if (!res.ok) { setErr(j.error || "Something went wrong."); setBusy(null); return; }
      window.location.href = j.url;
    } catch { setErr("Network error. Try again."); setBusy(null); }
  }

  return (
    <div className="mt-4 space-y-3 text-left">
      <label className="block text-sm text-mute" htmlFor="pay-email">Email for your receipt</label>
      <input id="pay-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com"
        className="w-full rounded-lg border border-edge bg-ink px-3 py-2.5 text-white placeholder:text-mute" />
      <div className="grid grid-cols-2 gap-3">
        {(Object.keys(PLANS) as PlanKey[]).map((k) => (
          <button key={k} onClick={() => pay(k)} disabled={!!busy}
            className={`rounded-lg px-3 py-3 font-semibold disabled:opacity-60 ${k === "week" ? "bg-neon text-ink" : "border border-neon text-neon"}`}>
            {busy === k ? "Opening Paystack..." : `${PLANS[k].label} - ${PLANS[k].price}`}
          </button>
        ))}
      </div>
      {err && <p role="alert" className="text-sm text-red-400">{err}</p>}
    </div>
  );
}
