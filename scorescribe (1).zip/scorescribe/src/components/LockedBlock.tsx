import PayPanel from "./PayPanel";

export default function LockedBlock({ items, next }: { items: { id: string; match: string }[]; next: string }) {
  return (
    <section className="relative mt-4" aria-label="Locked tips">
      <div aria-hidden className="pointer-events-none select-none space-y-4">
        {items.map((i) => (
          <div key={i.id} className="rounded-2xl border border-edge bg-panel p-5">
            <h3 className="font-display text-lg font-semibold">{i.match}</h3>
            <div className="blur-md">
              <div className="mt-3 h-8 w-40 rounded-lg bg-neon" />
              <div className="mt-4 h-2 rounded-full bg-edge" />
              <div className="mt-4 h-3 w-full rounded bg-edge" />
              <div className="mt-2 h-3 w-4/5 rounded bg-edge" />
            </div>
          </div>
        ))}
      </div>
      <div className="absolute inset-x-0 top-6 flex justify-center px-2">
        <div className="w-full max-w-md rounded-2xl border border-neon/50 bg-ink/95 p-6 text-center shadow-2xl">
          <p className="font-display text-xl font-semibold">🔒 Unlock {items.length} more tips for this Gameweek - Pay ₦4,900</p>
          <p className="mt-1 text-sm text-mute">Or get 30 days for ₦17,900.</p>
          <PayPanel next={next} />
        </div>
      </div>
    </section>
  );
}
