import Link from "next/link";

export default function Header() {
  return (
    <header className="border-b border-edge">
      <div className="mx-auto flex max-w-3xl items-center justify-between px-4 py-4">
        <Link href="/" className="flex items-center gap-2 font-display text-xl font-bold">
          <svg width="26" height="26" viewBox="0 0 26 26" fill="none" aria-hidden>
            <circle cx="13" cy="13" r="11.5" stroke="#00ff88" strokeWidth="2" />
            <path d="M6 17l5-5 3 3 6-7" stroke="#00ff88" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          ScoreScribe
        </Link>
        <Link href="/#vip" className="rounded-full bg-neon px-4 py-1.5 text-sm font-semibold text-ink">Go VIP</Link>
      </div>
    </header>
  );
}
