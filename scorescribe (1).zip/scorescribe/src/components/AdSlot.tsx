"use client";
import { useEffect } from "react";

export default function AdSlot() {
  const client = process.env.NEXT_PUBLIC_ADSENSE_CLIENT;
  const slot = process.env.NEXT_PUBLIC_ADSENSE_SLOT;
  useEffect(() => {
    if (!client || !slot) return;
    try { ((window as any).adsbygoogle = (window as any).adsbygoogle || []).push({}); } catch {}
  }, [client, slot]);

  if (!client || !slot) {
    return <div className="flex h-24 items-center justify-center rounded-xl border border-dashed border-edge text-sm text-mute">Ad space</div>;
  }
  return <ins className="adsbygoogle block" style={{ display: "block" }} data-ad-client={client} data-ad-slot={slot} data-ad-format="auto" data-full-width-responsive="true" />;
}
