import Link from 'next/link';
import Logo from './Logo';

export default function Nav() {
  return (
    <header className="border-b border-line">
      <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-4">
        <Link href="/" className="flex items-center gap-2 text-lg font-bold text-white">
          <Logo /> ScoreScribe
        </Link>
        <nav className="flex items-center gap-5 text-sm">
          <Link href="/" className="text-neutral-400 hover:text-white">Leagues</Link>
          <Link href="/vip" className="rounded-full bg-neon px-4 py-1.5 font-semibold text-black hover:brightness-110">VIP</Link>
        </nav>
      </div>
    </header>
  );
}
