import type { PublicTip } from '@/lib/tips';

export default function TipCard({ t }: { t: PublicTip }) {
  return (
    <article className="rounded-xl border border-line bg-panel p-4">
      <h3 className="font-semibold text-white">{t.match}</h3>
      <div className="mt-3 flex flex-wrap items-center gap-2">
        <span className="rounded-md bg-neon px-2.5 py-1 text-sm font-bold text-black">{t.tip}</span>
        {t.odd && <span className="text-sm text-neutral-400">Odds {t.odd}</span>}
      </div>
      <div className="mt-3 flex items-center gap-3">
        <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-line" role="progressbar" aria-valuenow={t.confidence} aria-valuemin={0} aria-valuemax={100}>
          <div className="h-full bg-neon" style={{ width: `${t.confidence}%` }} />
        </div>
        <span className="text-sm font-semibold text-neon">{t.confidence}%</span>
      </div>
      <p className="mt-3 text-sm leading-relaxed text-neutral-300">{t.analysis}</p>
    </article>
  );
}
