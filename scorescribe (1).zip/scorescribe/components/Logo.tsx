export default function Logo({ size = 28 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" aria-hidden="true">
      <circle cx="16" cy="16" r="14" stroke="#00ff88" strokeWidth="2" />
      <polyline points="8,21 14,15 18,18 24,10" stroke="#00ff88" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
      <polyline points="19,10 24,10 24,15" stroke="#00ff88" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
