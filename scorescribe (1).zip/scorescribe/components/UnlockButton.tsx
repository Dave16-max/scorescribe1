'use client';
import { useState } from 'react';

export default function UnlockButton({ plan, label, returnTo }: { plan: 'week' | 'month'; label: string; returnTo: string }) {
  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  async function pay() {
    setBusy(true); setErr('');
    try {
      const r = await fetch('/api/paystack/initialize', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ plan, email, returnTo }),
      });
      const j = await r.json();
      if (!r.ok || !j.url) throw new Error(j.error || 'Payment could not start');
      window.location.href = j.url;
    } catch (e: any) { setErr(e.message); setBusy(false); }
  }

  if (!open) {
    return (
      <button onClick={() => setOpen(true)} className="w-full rounded-lg bg-neon px-4 py-2.5 text-sm font-bold text-black hover:brightness-110">
        {label}
      </button>
    );
  }
  return (
    <div className="space-y-2">
      <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email for your receipt"
        className="w-full rounded-lg border border-line bg-ink px-3 py-2 text-sm text-white placeholder:text-neutral-500" />
      <button onClick={pay} disabled={busy || !email}
        className="w-full rounded-lg bg-neon px-4 py-2.5 text-sm font-bold text-black disabled:opacity-50">
        {busy ? 'Opening Paystack…' : 'Continue to Paystack'}
      </button>
      {err && <p className="text-xs text-red-400">{err}</p>}
    </div>
  );
}
