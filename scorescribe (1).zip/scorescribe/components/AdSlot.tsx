'use client';
import { useEffect } from 'react';

const CLIENT = process.env.NEXT_PUBLIC_ADSENSE_CLIENT;

export default function AdSlot() {
  useEffect(() => {
    if (!CLIENT) return;
    try { ((window as any).adsbygoogle = (window as any).adsbygoogle || []).push({}); } catch {}
  }, []);

  if (!CLIENT) {
    return <div className="mt-2 rounded-lg border border-dashed border-line py-4 text-center text-xs text-neutral-600">Ad space</div>;
  }
  return (
    <ins className="adsbygoogle mt-2 block" style={{ display: 'block' }}
      data-ad-client={CLIENT} data-ad-format="auto" data-full-width-responsive="true" />
  );
}
