import type { PublicTip } from '@/lib/tips';
import UnlockButton from './UnlockButton';

export default function LockedCard({ t, returnTo }: { t: PublicTip; returnTo: string }) {
  return (
    <article className="relative overflow-hidden rounded-xl border border-line bg-panel p-4">
      <h3 className="font-semibold text-white">{t.match}</h3>
      {/* Placeholder shapes only; the real tip is never sent to the browser. */}
      <div className="mt-3 select-none space-y-2 blur-sm" aria-hidden="true">
        <div className="h-7 w-32 rounded-md bg-neon/70" />
        <div className="h-1.5 w-full rounded-full bg-line" />
        <div className="h-3 w-full rounded bg-neutral-700" />
        <div className="h-3 w-4/5 rounded bg-neutral-700" />
      </div>
      <div className="absolute inset-x-4 bottom-4">
        <UnlockButton plan="week" returnTo={returnTo} label="🔒 Unlock 7 more tips for this Gameweek - Pay ₦4,900" />
      </div>
      <div className="h-12" />
    </article>
  );
}
