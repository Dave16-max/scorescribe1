import { notFound } from 'next/navigation';
import AdSlot from '@/components/AdSlot';
import LockedCard from '@/components/LockedCard';
import TipCard from '@/components/TipCard';
import { bySlug } from '@/lib/leagues';
import { isPremium } from '@/lib/premium';
import { getLeagueTips } from '@/lib/tips';

export const dynamic = 'force-dynamic';

export default async function LeaguePage({ params }: { params: { league: string } }) {
  const league = bySlug(params.league);
  if (!league) notFound();

  const premium = await isPremium();
  const { gameweek, tips } = await getLeagueTips(league, premium);

  return (
    <div>
      <h1 className="text-3xl font-extrabold text-white">{league.name}</h1>
      <p className="mt-1 text-neutral-400">
        {gameweek ? `Gameweek ${gameweek}` : 'No tips yet'}
        {premium && <span className="ml-3 rounded-full bg-neon px-2 py-0.5 text-xs font-bold text-black">VIP</span>}
      </p>

      {tips.length === 0 ? (
        <p className="mt-8 rounded-xl border border-line bg-panel p-6 text-neutral-400">
          New tips are published every Friday at 6am. Check back then.
        </p>
      ) : (
        <div className="mt-6 grid gap-4 md:grid-cols-2">
          {tips.map((t) =>
            t.locked ? (
              <LockedCard key={t.id} t={t} returnTo={`/${league.slug}`} />
            ) : (
              <div key={t.id}>
                <TipCard t={t} />
                {!premium && t.is_free && <AdSlot />}
              </div>
            ),
          )}
        </div>
      )}
    </div>
  );
}
