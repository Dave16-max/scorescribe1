import { NextResponse } from 'next/server';
import { LEAGUES } from '@/lib/leagues';

// Vercel cron: Friday 05:00 UTC = 06:00 WAT. Fans out one /api/generate call per league
// so each league gets its own function invocation and timeout.
export const maxDuration = 300;
export const dynamic = 'force-dynamic';

export async function GET(req: Request) {
  if (req.headers.get('authorization') !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  const origin = new URL(req.url).origin;
  const results = await Promise.allSettled(
    LEAGUES.map((l) =>
      fetch(`${origin}/api/generate?league=${l.slug}`, {
        headers: { authorization: `Bearer ${process.env.CRON_SECRET}` },
      }).then((r) => r.json()),
    ),
  );
  return NextResponse.json({
    ok: true,
    results: results.map((r, i) => ({ league: LEAGUES[i].slug, status: r.status })),
  });
}
