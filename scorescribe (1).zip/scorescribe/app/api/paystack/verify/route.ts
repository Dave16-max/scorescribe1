import { NextResponse } from 'next/server';
import { PLANS, type PlanKey } from '@/lib/leagues';
import { COOKIE, cookieValue } from '@/lib/premium';
import { db } from '@/lib/supabase';

export async function GET(req: Request) {
  const url = new URL(req.url);
  const reference = url.searchParams.get('reference') || url.searchParams.get('trxref');
  const fail = () => NextResponse.redirect(new URL('/vip?error=payment', url.origin));
  if (!reference) return fail();

  const res = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
    headers: { Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}` },
    cache: 'no-store',
  });
  const json = await res.json();
  const d = json?.data;
  const plan = d?.metadata?.plan as PlanKey;
  const p = PLANS[plan];

  // Must be paid, in NGN, and match the plan price exactly.
  if (!res.ok || d?.status !== 'success' || d?.currency !== 'NGN' || !p || d.amount !== p.amount) return fail();

  const expires = new Date(Date.now() + p.days * 86400000);
  const { error } = await db().from('scorescribe_premium').upsert(
    { reference, email: d.customer.email, plan, is_premium: true, expires_at: expires.toISOString() },
    { onConflict: 'reference' },
  );
  if (error) return fail();

  const rt = d.metadata?.returnTo;
  const dest = typeof rt === 'string' && rt.startsWith('/') && !rt.startsWith('//') ? rt : '/';
  const out = NextResponse.redirect(new URL(dest, url.origin));
  out.cookies.set(COOKIE, cookieValue(reference), {
    httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax',
    path: '/', maxAge: p.days * 86400,
  });
  return out;
}
