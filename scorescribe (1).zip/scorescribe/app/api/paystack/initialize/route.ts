import crypto from 'crypto';
import { NextResponse } from 'next/server';
import { PLANS, type PlanKey } from '@/lib/leagues';

export async function POST(req: Request) {
  const { plan, email, returnTo } = await req.json();
  const p = PLANS[plan as PlanKey];
  if (!p) return NextResponse.json({ error: 'Invalid plan' }, { status: 400 });
  if (typeof email !== 'string' || !/^\S+@\S+\.\S+$/.test(email)) {
    return NextResponse.json({ error: 'Enter a valid email' }, { status: 400 });
  }

  const origin = process.env.NEXT_PUBLIC_SITE_URL || new URL(req.url).origin;
  const res = await fetch('https://api.paystack.co/transaction/initialize', {
    method: 'POST',
    headers: { Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email,
      amount: p.amount, // kobo
      currency: 'NGN',
      reference: `ss_${crypto.randomUUID()}`,
      callback_url: `${origin}/api/paystack/verify`,
      metadata: { plan, returnTo: typeof returnTo === 'string' ? returnTo : '/' },
    }),
  });
  const json = await res.json();
  if (!res.ok || !json.status) return NextResponse.json({ error: 'Payment could not start' }, { status: 502 });
  return NextResponse.json({ url: json.data.authorization_url });
}
