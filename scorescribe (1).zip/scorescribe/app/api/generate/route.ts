import { NextResponse } from 'next/server';
import { processLeague } from '@/lib/generate';
import { LEAGUES, bySlug } from '@/lib/leagues';

export const maxDuration = 300;
export const dynamic = 'force-dynamic';

async function handle(req: Request) {
  if (req.headers.get('authorization') !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  const slug = new URL(req.url).searchParams.get('league');
  const targets = slug ? [bySlug(slug)] : LEAGUES;
  if (targets.some((t) => !t)) return NextResponse.json({ error: 'Unknown league' }, { status: 404 });

  const out = [];
  for (const l of targets) {
    try { out.push(await processLeague(l!)); }
    catch (e: any) { out.push({ league: l!.name, error: e.message }); }
  }
  return NextResponse.json({ ok: true, out });
}

export const GET = handle;
export const POST = handle;
