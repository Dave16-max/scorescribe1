import Link from 'next/link';
import { LEAGUES } from '@/lib/leagues';

export default function Home() {
  const groups = ['Football', 'Basketball'] as const;
  return (
    <div className="space-y-10">
      <section>
        <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl">Data-Driven Football Predictions</h1>
        <p className="mt-3 max-w-xl text-neutral-400">
          Every tip comes from head-to-head records and recent form. Goals, corners, cards and handicaps only. Never a straight win.
        </p>
      </section>
      {groups.map((g) => (
        <section key={g}>
          <h2 className="mb-3 text-lg font-semibold text-white">{g}</h2>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            {LEAGUES.filter((l) => l.sport === g).map((l) => (
              <Link key={l.slug} href={`/${l.slug}`}
                className="rounded-xl border border-line bg-panel px-4 py-5 font-medium text-white transition-colors hover:border-neon hover:text-neon">
                {l.name}
              </Link>
            ))}
          </div>
        </section>
      ))}
    </div>
  );
}
