import type { Metadata } from 'next';
import { Bricolage_Grotesque } from 'next/font/google';
import Script from 'next/script';
import Nav from '@/components/Nav';
import './globals.css';

const font = Bricolage_Grotesque({ subsets: ['latin'], variable: '--font-sans' });

export const metadata: Metadata = {
  title: 'ScoreScribe | Data-Driven Football Predictions',
  description: 'Football and basketball tips built from head-to-head data and recent form.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const ads = process.env.NEXT_PUBLIC_ADSENSE_CLIENT;
  return (
    <html lang="en" className={font.variable}>
      <body className="font-sans">
        {ads && (
          <Script async strategy="afterInteractive" crossOrigin="anonymous"
            src={`https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${ads}`} />
        )}
        <Nav />
        <main className="mx-auto max-w-5xl px-4 py-8">{children}</main>
        <footer className="border-t border-line py-6 text-center text-xs text-neutral-500">
          Tips are analysis, not guarantees. 18+ only. Bet responsibly.
        </footer>
      </body>
    </html>
  );
}
