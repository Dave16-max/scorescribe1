import UnlockButton from '@/components/UnlockButton';
import { PLANS } from '@/lib/leagues';
import { isPremium } from '@/lib/premium';

export const dynamic = 'force-dynamic';

export default async function Vip({ searchParams }: { searchParams: { error?: string } }) {
  const premium = await isPremium();
  const plans = [
    { key: 'week' as const, price: PLANS.week.naira, label: PLANS.week.label },
    { key: 'month' as const, price: PLANS.month.naira, label: PLANS.month.label },
  ];
  return (
    <div className="mx-auto max-w-2xl">
      <h1 className="text-3xl font-extrabold text-white">VIP access</h1>
      <p className="mt-2 text-neutral-400">Unlock all 10 tips in every league, football and basketball.</p>
      {searchParams.error && (
        <p className="mt-4 rounded-lg border border-red-500/40 p-3 text-sm text-red-300">
          We couldn't confirm that payment. If you were charged, contact support with your Paystack receipt.
        </p>
      )}
      {premium ? (
        <p className="mt-6 rounded-xl border border-neon p-5 text-neon">Your VIP access is active.</p>
      ) : (
        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          {plans.map((p) => (
            <div key={p.key} className="rounded-xl border border-line bg-panel p-5">
              <div className="text-sm text-neutral-400">{p.label}</div>
              <div className="mt-1 text-3xl font-extrabold text-white">₦{p.price.toLocaleString('en-NG')}</div>
              <div className="mt-4"><UnlockButton plan={p.key} returnTo="/vip" label={`Pay ₦${p.price.toLocaleString('en-NG')}`} /></div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
