import { BASKETBALL_SEASON, FOOTBALL_SEASON, MATCHES_PER_LEAGUE, type League } from './leagues';

const FB = 'https://v3.football.api-sports.io';
const BB = 'https://v3.basketball.api-sports.io';

async function api(base: string, path: string): Promise<any[]> {
  const key = process.env.API_FOOTBALL_KEY; // server only
  if (!key) throw new Error('API_FOOTBALL_KEY is not set');
  const res = await fetch(`${base}${path}`, { headers: { 'x-apisports-key': key }, cache: 'no-store' });
  if (!res.ok) throw new Error(`API-Sports ${res.status} for ${path}`);
  const json = await res.json();
  return json.response ?? [];
}

export interface Fixture {
  id: number; date: string; round: string | null;
  homeId: number; homeName: string; awayId: number; awayName: string;
}

export async function getFixtures(l: League): Promise<Fixture[]> {
  if (l.sport === 'Football') {
    const items = await api(FB, `/fixtures?league=${l.id}&season=${FOOTBALL_SEASON}`);
    return items
      .filter((x) => x.fixture?.status?.short === 'NS')
      .sort((a, b) => +new Date(a.fixture.date) - +new Date(b.fixture.date))
      .slice(0, MATCHES_PER_LEAGUE)
      .map((x) => ({
        id: x.fixture.id, date: x.fixture.date, round: x.league?.round ?? null,
        homeId: x.teams.home.id, homeName: x.teams.home.name,
        awayId: x.teams.away.id, awayName: x.teams.away.name,
      }));
  }
  const items = await api(BB, `/games?league=${l.id}&season=${BASKETBALL_SEASON}`);
  return items
    .filter((x) => x.status?.short === 'NS')
    .sort((a, b) => +new Date(a.date) - +new Date(b.date))
    .slice(0, MATCHES_PER_LEAGUE)
    .map((x) => ({
      id: x.id, date: x.date, round: null,
      homeId: x.teams.home.id, homeName: x.teams.home.name,
      awayId: x.teams.away.id, awayName: x.teams.away.name,
    }));
}

const pct = (n: number, d: number) => (d ? Math.round((n / d) * 100) : 0);
const avg = (n: number, d: number) => (d ? +(n / d).toFixed(2) : 0);

export async function getFootballContext(f: Fixture) {
  const [h2hRaw, homeRaw, awayRaw] = await Promise.all([
    api(FB, `/fixtures/headtohead?h2h=${f.homeId}-${f.awayId}&last=10`),
    api(FB, `/fixtures?team=${f.homeId}&last=5`),
    api(FB, `/fixtures?team=${f.awayId}&last=5`),
  ]);
  const done = (arr: any[]) => arr.filter((x) => x.goals?.home != null && x.goals?.away != null);

  const h = done(h2hRaw);
  const goals = h.map((x) => x.goals.home + x.goals.away);
  const h2h = h.length
    ? {
        matches: h.length,
        avgGoals: avg(goals.reduce((a, b) => a + b, 0), h.length),
        over15Pct: pct(goals.filter((g) => g > 1).length, h.length),
        over25Pct: pct(goals.filter((g) => g > 2).length, h.length),
        bttsPct: pct(h.filter((x) => x.goals.home > 0 && x.goals.away > 0).length, h.length),
        recent: h.slice(-5).map((x) => `${x.teams.home.name} ${x.goals.home}-${x.goals.away} ${x.teams.away.name}`),
      }
    : 'No H2H data available';

  const form = (arr: any[], teamId: number) => {
    const rows = done(arr).sort((a, b) => +new Date(b.fixture.date) - +new Date(a.fixture.date)).slice(0, 5);
    if (!rows.length) return 'No recent form data';
    let gf = 0, ga = 0, btts = 0, o25 = 0;
    const res = rows.map((x) => {
      const home = x.teams.home.id === teamId;
      const f1 = home ? x.goals.home : x.goals.away;
      const a1 = home ? x.goals.away : x.goals.home;
      gf += f1; ga += a1;
      if (f1 > 0 && a1 > 0) btts++;
      if (f1 + a1 > 2) o25++;
      return f1 > a1 ? 'W' : f1 < a1 ? 'L' : 'D';
    });
    return { last5: res.join(''), goalsForPerGame: avg(gf, rows.length), goalsAgainstPerGame: avg(ga, rows.length), bttsOf5: btts, over25Of5: o25 };
  };

  return { h2h, form: { [f.homeName]: form(homeRaw, f.homeId), [f.awayName]: form(awayRaw, f.awayId) } };
}

export async function getBasketballContext(f: Fixture) {
  const [h2hRaw, homeRaw, awayRaw] = await Promise.all([
    api(BB, `/games/h2h?h2h=${f.homeId}-${f.awayId}`),
    api(BB, `/games?team=${f.homeId}&season=${BASKETBALL_SEASON}`),
    api(BB, `/games?team=${f.awayId}&season=${BASKETBALL_SEASON}`),
  ]);
  const total = (x: any, side: 'home' | 'away') => x.scores?.[side]?.total as number | null;
  const done = (arr: any[]) => arr.filter((x) => total(x, 'home') != null && total(x, 'away') != null);

  const h = done(h2hRaw).sort((a, b) => +new Date(a.date) - +new Date(b.date));
  const sums = h.map((x) => total(x, 'home')! + total(x, 'away')!);
  const h2h = h.length
    ? {
        matches: h.length,
        avgTotalPoints: avg(sums.reduce((a, b) => a + b, 0), h.length),
        avgMargin: avg(h.reduce((a, x) => a + Math.abs(total(x, 'home')! - total(x, 'away')!), 0), h.length),
        recent: h.slice(-5).map((x) => `${x.teams.home.name} ${total(x, 'home')}-${total(x, 'away')} ${x.teams.away.name}`),
      }
    : 'No H2H data available';

  const form = (arr: any[], teamId: number) => {
    const rows = done(arr).sort((a, b) => +new Date(b.date) - +new Date(a.date)).slice(0, 5);
    if (!rows.length) return 'No games played yet this season';
    let pf = 0, pa = 0;
    const res = rows.map((x) => {
      const home = x.teams.home.id === teamId;
      const f1 = total(x, home ? 'home' : 'away')!;
      const a1 = total(x, home ? 'away' : 'home')!;
      pf += f1; pa += a1;
      return f1 > a1 ? 'W' : 'L';
    });
    return { last5: res.join(''), pointsForPerGame: avg(pf, rows.length), pointsAgainstPerGame: avg(pa, rows.length) };
  };

  return { h2h, form: { [f.homeName]: form(homeRaw, f.homeId), [f.awayName]: form(awayRaw, f.awayId) } };
}
