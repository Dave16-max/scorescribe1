import type { League } from './leagues';
import { isForbiddenTip } from './rules';
import { db } from './supabase';

export interface PublicTip {
  id: string; match: string; home_team: string; away_team: string; is_free: boolean;
  locked: boolean; tip?: string; odd?: string; confidence?: number; analysis?: string;
}

export async function getLeagueTips(l: League, premium: boolean) {
  const sb = db();
  const { data: latest } = await sb
    .from('scorescribe_tips').select('gameweek')
    .eq('league', l.name).eq('sport', l.sport)
    .order('created_at', { ascending: false }).limit(1);
  if (!latest?.length) return { gameweek: null as number | null, tips: [] as PublicTip[] };

  const gameweek = latest[0].gameweek as number;
  const { data } = await sb
    .from('scorescribe_tips').select('*')
    .eq('league', l.name).eq('sport', l.sport).eq('gameweek', gameweek)
    .order('is_free', { ascending: false }).order('created_at', { ascending: true })
    .limit(10);

  const tips: PublicTip[] = (data ?? [])
    .filter((r) => !isForbiddenTip(r.tip))
    .map((r) => {
      const locked = !r.is_free && !premium;
      const base = { id: r.id, match: r.match, home_team: r.home_team, away_team: r.away_team, is_free: r.is_free, locked };
      // Locked tip content never leaves the server.
      return locked ? base : { ...base, tip: r.tip, odd: r.odd, confidence: r.confidence, analysis: r.analysis };
    });

  return { gameweek, tips };
}
