export type Sport = 'Football' | 'Basketball';
export interface League { slug: string; name: string; id: number; sport: Sport }

export const LEAGUES: League[] = [
  { slug: 'premier-league', name: 'Premier League', id: 39, sport: 'Football' },
  { slug: 'ligue-1', name: 'Ligue 1', id: 61, sport: 'Football' },
  { slug: 'la-liga', name: 'La Liga', id: 140, sport: 'Football' },
  { slug: 'bundesliga', name: 'Bundesliga', id: 78, sport: 'Football' },
  { slug: 'serie-a', name: 'Serie A', id: 135, sport: 'Football' },
  { slug: 'champions-league', name: 'Champions League', id: 2, sport: 'Football' },
  { slug: 'europa-league', name: 'Europa League', id: 3, sport: 'Football' },
  { slug: 'conference-league', name: 'Conference League', id: 848, sport: 'Football' },
  { slug: 'nba', name: 'NBA', id: 12, sport: 'Basketball' },
  { slug: 'ncaa', name: 'NCAA', id: 1, sport: 'Basketball' },
  { slug: 'wnba', name: 'WNBA', id: 13, sport: 'Basketball' },
  { slug: 'euroleague', name: 'Euroleague', id: 3, sport: 'Basketball' },
];

export const bySlug = (s: string) => LEAGUES.find((l) => l.slug === s);

export const FOOTBALL_SEASON = '2026';
export const BASKETBALL_SEASON = '2026-2027';
export const MATCHES_PER_LEAGUE = 10;
export const FREE_PER_LEAGUE = 3;
// Football and basketball fixture ids can collide; offset basketball so fixture_id stays unique.
export const BB_OFFSET = 1_000_000_000;

export const PLANS = {
  week: { label: '7 days', amount: 490000, naira: 4900, days: 7 },
  month: { label: '30 days', amount: 1790000, naira: 17900, days: 30 },
} as const;
export type PlanKey = keyof typeof PLANS;
