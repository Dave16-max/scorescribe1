import type { Sport } from './leagues';

const FOOTBALL = [
  /^BTTS (Yes|No)$/i,
  /^Over 1\.5 Goals$/i,
  /^Over 2\.5 Goals$/i,
  /^Under 2\.5 Goals$/i,
  /^Double Chance (1X|X2)$/i,
  /^Over 8\.5 Corners$/i,
  /^Over 3\.5 Cards$/i,
];
const BASKETBALL = [
  /^(Over|Under) \d{2,3}(\.5)?( Total Points)?$/i,
  /^(Home|Away) [+-]\d{1,2}(\.5)?$/i,
  /^(Home|Away) (Over|Under) \d{2,3}(\.5)?( Points)?$/i,
];

export const isAllowedTip = (sport: Sport, tip: string) =>
  (sport === 'Football' ? FOOTBALL : BASKETBALL).some((r) => r.test(tip.trim()));

// Second line of defence on the frontend: never render a straight-win style tip.
export const isForbiddenTip = (tip: string) =>
  /\b(home win|away win|draw|moneyline|winner|1x2)\b/i.test(tip) || /^(1|x|2)$/i.test(tip.trim());
