import { getBasketballContext, getFixtures, getFootballContext, type Fixture } from './apisports';
import { generateTip } from './claude';
import { BB_OFFSET, FREE_PER_LEAGUE, type League } from './leagues';
import { db } from './supabase';

function isoWeek(d: Date) {
  const t = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
  const day = t.getUTCDay() || 7;
  t.setUTCDate(t.getUTCDate() + 4 - day);
  const y = new Date(Date.UTC(t.getUTCFullYear(), 0, 1));
  return Math.ceil(((+t - +y) / 86400000 + 1) / 7);
}

// "Regular Season - 8" -> 8. Cup rounds without a trailing "- N" fall back to the ISO week.
function gameweekOf(f: Fixture) {
  const m = f.round?.match(/-\s*(\d+)\s*$/);
  return m ? parseInt(m[1], 10) : isoWeek(new Date(f.date));
}

async function pool<T, R>(items: T[], n: number, fn: (t: T) => Promise<R>): Promise<R[]> {
  const out: R[] = new Array(items.length);
  let i = 0;
  await Promise.all(
    Array.from({ length: Math.min(n, items.length) }, async () => {
      while (i < items.length) {
        const k = i++;
        out[k] = await fn(items[k]);
      }
    }),
  );
  return out;
}

export async function processLeague(l: League) {
  const fixtures = await getFixtures(l);
  if (!fixtures.length) return { league: l.name, saved: 0, skipped: 0, note: 'No upcoming fixtures' };

  const gameweek = gameweekOf(fixtures[0]);

  const results = await pool(fixtures, 3, async (f) => {
    try {
      const ctx = l.sport === 'Football' ? await getFootballContext(f) : await getBasketballContext(f);
      const match = `${f.homeName} vs ${f.awayName}`;
      const t = await generateTip({ sport: l.sport, league: l.name, match, h2h: ctx.h2h, form: ctx.form });
      return { f, match, t };
    } catch (e) {
      console.error(`[generate] ${l.name} fixture ${f.id}:`, e);
      return null;
    }
  });

  const ok = results.filter((r): r is NonNullable<typeof r> => r !== null);
  const base = Date.now();

  // First 3 per league are free, remaining 7 are locked.
  const rows = ok.map(({ f, match, t }, i) => ({
    sport: l.sport,
    league: l.name,
    gameweek,
    match,
    home_team: f.homeName,
    away_team: f.awayName,
    tip: t.tip,
    analysis: t.analysis,
    confidence: t.confidence,
    odd: t.odd,
    is_free: i < FREE_PER_LEAGUE,
    fixture_id: l.sport === 'Basketball' ? BB_OFFSET + f.id : f.id,
    created_at: new Date(base + i * 1000).toISOString(),
  }));

  if (rows.length) {
    const { error } = await db().from('scorescribe_tips').upsert(rows, { onConflict: 'fixture_id' });
    if (error) throw new Error(error.message);
  }
  return { league: l.name, saved: rows.length, skipped: fixtures.length - rows.length };
}
