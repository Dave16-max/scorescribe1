import type { Sport } from './leagues';
import { isAllowedTip } from './rules';

export interface TipResult { tip: string; odd: string; confidence: number; analysis: string }

const buildPrompt = (sport: Sport, league: string, match: string, h2h: unknown, form: unknown) =>
  `You are ScoreScribe analyst. REAL DATA: Sport: ${sport}, League: ${league}, Fixture: ${match}, H2H: ${JSON.stringify(h2h)}, Form: ${JSON.stringify(form)}. RULE: NEVER predict straight win. FORBIDDEN tips: Home Win, Away Win, Draw, 1, X, 2, 1X2, Moneyline, Winner. ONLY ALLOWED: For Football: BTTS Yes/No, Over 1.5 Goals, Over 2.5 Goals, Under 2.5 Goals, Double Chance (1X or X2), Over 8.5 Corners, Over 3.5 Cards. For Basketball: Over/Under Total Points e.g Over 215.5, Under 210.5, Handicap/Spread e.g Home -5.5, Away +6.5, Over/Under Team Points. TASK: Give tip from allowed list only, 2 sentence analysis using H2H stats, confidence %. JSON only: {"tip":"Over 2.5 Goals","odd":"1.85","confidence":81,"analysis":"sentence 1 with H2H stat. sentence 2."}`;

function parse(text: string): any {
  const start = text.indexOf('{');
  const end = text.lastIndexOf('}');
  if (start < 0 || end < 0) throw new Error('No JSON in reply');
  return JSON.parse(text.slice(start, end + 1));
}

export async function generateTip(args: {
  sport: Sport; league: string; match: string; h2h: unknown; form: unknown;
}): Promise<TipResult> {
  const prompt = buildPrompt(args.sport, args.league, args.match, args.h2h, args.form);
  let lastErr: unknown;

  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          'x-api-key': process.env.ANTHROPIC_API_KEY!,
          'anthropic-version': '2023-06-01',
        },
        body: JSON.stringify({
          model: 'claude-sonnet-5-5',
          max_tokens: 400,
          messages: [{ role: 'user', content: prompt }],
        }),
      });
      if (!res.ok) throw new Error(`Claude ${res.status}`);
      const data = await res.json();
      const text = (data.content ?? []).map((b: any) => b.text ?? '').join('');
      const j = parse(text);

      const tip = String(j.tip ?? '').trim();
      if (!isAllowedTip(args.sport, tip)) throw new Error(`Disallowed tip: ${tip}`);

      return {
        tip,
        odd: String(j.odd ?? '').trim(),
        confidence: Math.max(1, Math.min(99, Math.round(Number(j.confidence) || 0))),
        analysis: String(j.analysis ?? '').trim(),
      };
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr;
}
