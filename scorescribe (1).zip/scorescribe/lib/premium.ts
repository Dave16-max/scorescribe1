import crypto from 'crypto';
import { cookies } from 'next/headers';
import { db } from './supabase';

export const COOKIE = 'ss_premium';

const sign = (ref: string) =>
  crypto.createHmac('sha256', process.env.COOKIE_SECRET!).update(ref).digest('hex');

export const cookieValue = (ref: string) => `${ref}.${sign(ref)}`;

export async function isPremium(): Promise<boolean> {
  const raw = cookies().get(COOKIE)?.value;
  if (!raw) return false;
  const dot = raw.lastIndexOf('.');
  if (dot < 1) return false;
  const ref = raw.slice(0, dot);
  const sig = Buffer.from(raw.slice(dot + 1));
  const expected = Buffer.from(sign(ref));
  if (sig.length !== expected.length || !crypto.timingSafeEqual(sig, expected)) return false;

  const { data } = await db()
    .from('scorescribe_premium')
    .select('is_premium, expires_at')
    .eq('reference', ref)
    .maybeSingle();
  return !!data?.is_premium && new Date(data.expires_at) > new Date();
}
