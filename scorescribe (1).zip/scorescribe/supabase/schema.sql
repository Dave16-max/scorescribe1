create extension if not exists "pgcrypto";

create table if not exists scorescribe_tips (
  id uuid primary key default gen_random_uuid(),
  sport text not null check (sport in ('Football','Basketball')),
  league text not null,
  gameweek int not null,
  match text not null,
  home_team text not null,
  away_team text not null,
  tip text not null,
  analysis text not null,
  confidence int not null,
  odd text,
  is_free boolean not null default false,
  fixture_id int unique not null,
  created_at timestamp not null default now()
);
create index if not exists scorescribe_tips_league_idx on scorescribe_tips (league, created_at desc);

create table if not exists scorescribe_premium (
  reference text primary key,
  email text not null,
  plan text not null,
  is_premium boolean not null default true,
  expires_at timestamptz not null,
  created_at timestamptz not null default now()
);

-- Server uses the service role key (bypasses RLS). No public policies = tips can't be read from the browser.
alter table scorescribe_tips enable row level security;
alter table scorescribe_premium enable row level security;
